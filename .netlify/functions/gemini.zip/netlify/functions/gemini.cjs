var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/gemini.js
var gemini_exports = {};
__export(gemini_exports, {
  default: () => gemini_default,
  health: () => health
});
module.exports = __toCommonJS(gemini_exports);
var responseCache = /* @__PURE__ */ new Map();
var CACHE_TTL = 5 * 60 * 1e3;
var gemini_default = async (request, context) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 200, headers });
  }
  if (request.method !== "POST") {
    return new Response(JSON.stringify({
      error: "Method not allowed"
    }), {
      status: 405,
      headers
    });
  }
  try {
    const { message, context: userContext } = await request.json();
    if (!message || typeof message !== "string") {
      return new Response(JSON.stringify({
        error: "Invalid message"
      }), {
        status: 400,
        headers
      });
    }
    const cacheKey = `${message}_${JSON.stringify(userContext)}`;
    const cached = responseCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      return new Response(JSON.stringify(cached.data), {
        status: 200,
        headers
      });
    }
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.error("Missing GEMINI_API_KEY");
      return new Response(JSON.stringify({
        response: "AI slu\u017Eba nen\xED moment\xE1ln\u011B dostupn\xE1. Pou\u017Eijte pros\xEDm kalkula\u010Dku.",
        fallback: true
      }), {
        status: 200,
        headers
      });
    }
    const systemPrompt = createSystemPrompt(userContext);
    const apiResponse = await callGeminiAPI(apiKey, message, systemPrompt);
    const result = parseGeminiResponse(apiResponse);
    responseCache.set(cacheKey, {
      data: result,
      timestamp: Date.now()
    });
    cleanCache();
    return new Response(JSON.stringify(result), {
      status: 200,
      headers
    });
  } catch (error) {
    console.error("Gemini API error:", error);
    return new Response(JSON.stringify({
      response: getFallbackResponse(request.message),
      fallback: true,
      error: process.env.NODE_ENV === "development" ? error.message : void 0
    }), {
      status: 200,
      headers
    });
  }
};
function createSystemPrompt(context) {
  const hasCalculation = context && Object.keys(context).length > 0;
  return `Jsi profesion\xE1ln\xED hypote\u010Dn\xED poradce pro \u010Desk\xFD trh.

AKTU\xC1LN\xCD KONTEXT:
${hasCalculation ? JSON.stringify(context, null, 2) : "\u017D\xE1dn\xFD v\xFDpo\u010Det"}

PRAVIDLA:
1. Odpov\xEDdej stru\u010Dn\u011B a v\u011Bcn\u011B v \u010De\u0161tin\u011B
2. Pou\u017E\xEDvej aktu\xE1ln\xED sazby bank (4.09% - 5.49% pro 5letou fixaci)
3. P\u0159i v\xFDpo\u010Dtech zohledni DSTI limit 50% a LTV do 90%
4. Pokud nem\xE1\u0161 dost informac\xED, po\u017E\xE1dej o dopln\u011Bn\xED
5. V\u017Edy bu\u010F profesion\xE1ln\xED ale p\u0159\xE1telsk\xFD

D\u016ELE\u017DIT\xC9 INFORMACE:
- Minim\xE1ln\xED v\xFD\u0161e hypot\xE9ky: 300 000 K\u010D
- Maxim\xE1ln\xED v\xFD\u0161e: 20 000 000 K\u010D
- Standardn\xED doba splatnosti: 20-30 let
- Poplatek za vy\u0159\xEDzen\xED: 0-0.5% z \xFAv\u011Bru
- Odhad nemovitosti: 3000-5000 K\u010D

Odpov\u011Bz na dotaz u\u017Eivatele s ohledem na kontext.`;
}
async function callGeminiAPI(apiKey, message, systemPrompt, retries = 3) {
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
  const payload = {
    contents: [{
      parts: [{
        text: `${systemPrompt}

U\u017Eivatel: ${message}

Odpov\u011Bz:`
      }]
    }],
    generationConfig: {
      temperature: 0.7,
      topK: 40,
      topP: 0.95,
      maxOutputTokens: 1024
    },
    safetySettings: [
      {
        category: "HARM_CATEGORY_HARASSMENT",
        threshold: "BLOCK_MEDIUM_AND_ABOVE"
      },
      {
        category: "HARM_CATEGORY_HATE_SPEECH",
        threshold: "BLOCK_MEDIUM_AND_ABOVE"
      }
    ]
  };
  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(1e4)
        // 10s timeout
      });
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      const data = await response.json();
      return data;
    } catch (error) {
      console.error(`Gemini API attempt ${i + 1} failed:`, error.message);
      if (i === retries - 1) {
        throw error;
      }
      await new Promise((resolve) => setTimeout(resolve, Math.pow(2, i) * 1e3));
    }
  }
}
function parseGeminiResponse(apiResponse) {
  try {
    const text = apiResponse?.candidates?.[0]?.content?.parts?.[0]?.text || "";
    if (!text) {
      throw new Error("Empty response from Gemini");
    }
    return {
      response: text.trim(),
      success: true
    };
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    throw error;
  }
}
function getFallbackResponse(message) {
  const msg = message.toLowerCase();
  if (msg.includes("sazb") || msg.includes("\xFArok")) {
    return `Aktu\xE1ln\xED \xFArokov\xE9 sazby hypot\xE9k:
\u2022 3 roky: 4.29% - 4.79%
\u2022 5 let: 4.09% - 4.59%
\u2022 7 let: 4.19% - 4.69%
\u2022 10 let: 4.39% - 4.89%

Konkr\xE9tn\xED sazba z\xE1vis\xED na va\u0161\xED bonit\u011B, v\xFD\u0161i \xFAv\u011Bru a LTV.`;
  }
  if (msg.includes("kolik") && (msg.includes("p\u016Fj\u010D") || msg.includes("dost"))) {
    return `Maxim\xE1ln\xED v\xFD\u0161e hypot\xE9ky z\xE1vis\xED na:
\u2022 \u010Cist\xE9m m\u011Bs\xED\u010Dn\xEDm p\u0159\xEDjmu (max. 50% na spl\xE1tky)
\u2022 Hodnot\u011B nemovitosti (a\u017E 90% LTV)
\u2022 V\u011Bku a dob\u011B splatnosti
\u2022 Dal\u0161\xEDch z\xE1vazc\xEDch

Pro p\u0159esn\xFD v\xFDpo\u010Det vypl\u0148te na\u0161i kalkula\u010Dku.`;
  }
  if (msg.includes("refinanc")) {
    return `Refinancov\xE1n\xED se vyplat\xED kdy\u017E:
\u2022 Sou\u010Dasn\xE1 sazba je o 0.5% a v\xEDce vy\u0161\u0161\xED
\u2022 Do konce fixace zb\xFDv\xE1 max. 6 m\u011Bs\xEDc\u016F
\u2022 Chcete zm\u011Bnit parametry \xFAv\u011Bru

U\u0161et\u0159it m\u016F\u017Eete tis\xEDce korun m\u011Bs\xED\u010Dn\u011B!`;
  }
  if (msg.includes("dsti") || msg.includes("bonit")) {
    return `DSTI (pom\u011Br spl\xE1tek k p\u0159\xEDjmu):
\u2022 Do 40% - v\xFDborn\xE1 bonita
\u2022 40-45% - dobr\xE1 bonita
\u2022 45-50% - hrani\u010Dn\xED
\u2022 Nad 50% - problematick\xE9

Banky maj\xED limit 50% DSTI.`;
  }
  return `Pro zodpov\u011Bzen\xED va\u0161eho dotazu pot\u0159ebuji v\xEDce informac\xED. 
M\u016F\u017Eete mi pros\xEDm up\u0159esnit v\xE1\u0161 dotaz nebo vyplnit kalkula\u010Dku pro p\u0159esn\xFD v\xFDpo\u010Det?`;
}
function cleanCache() {
  const now = Date.now();
  for (const [key, value] of responseCache.entries()) {
    if (now - value.timestamp > CACHE_TTL) {
      responseCache.delete(key);
    }
  }
}
var health = async (request, context) => {
  return new Response(JSON.stringify({
    status: "ok",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  }), {
    status: 200,
    headers: { "Content-Type": "application/json" }
  });
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  health
});
